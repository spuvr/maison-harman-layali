MAISON HARMAN (دار حرمان) - 5 VERSIONS OF THE "LAYALI" HOMEPAGE
=================================================================

These are 5 versions of the same website design. You only need to look at them.
Nothing to install.


THE EASIEST WAY: OPEN THE LINK
------------------------------
1. Open this link (on your phone or your computer):

      https://spuvr.github.io/maison-harman-layali/

2. You will see 5 cards: Version 1 to Version 5.
   Each card shows two small pictures: the dark version (left) and the light version (right).
3. Click "Open version" on a card. The design opens in a NEW TAB.
4. Scroll down slowly to see the whole page.
5. When you are done, close that tab. You are back on the 5 cards.
   Open the next one.

The designs are made for phones first, so the phone is the best way to see them.


LIGHT MODE AND DARK MODE
------------------------
The website follows your phone or computer setting:
- if your device is in dark mode, you see the dark (night) version;
- if your device is in light mode, you see the light (day) version.
To see both, change your phone to light mode / dark mode and reload the page.
Versions 1, 3 and 4 also have a small sun / moon button at the top.


IF YOU USE THE ZIP FILE INSTEAD
-------------------------------
1. Unzip it:
   - Windows: right-click the zip file > "Extract All..." > "Extract".
   - Mac: double-click the zip file.
2. Open the new folder "Maison-Harman-Layali-5-Versions".
3. Double-click the file "OPEN-ME.html". It opens in your internet browser.
4. Click "Open version" on any card. It opens in a new tab.
   Close the tab to come back and open another one.
Keep the internet on: fonts and some effects load from the internet.


THINGS TO TRY ON EACH VERSION
-----------------------------
- The "FR | ع" button at the top: French or Arabic.
- In "Les plus demandés", choose 30 ml, 50 ml or 100 ml: the price changes.
- "Ajouter" puts the perfume in the bag: watch the bag number change.
- The trio: choose 3 perfumes and see the price.
- The WhatsApp buttons and the menu (three lines).

Note: photos, prices, reviews and social links are SAMPLES, only to show the design.
Tell us the number (1 to 5) of the version you like most.


------------------------------------------------------------
FRANÇAIS
------------------------------------------------------------
5 versions de la page d'accueil "Layali" pour Maison Harman (دار حرمان).

1. Ouvrez ce lien (téléphone ou ordinateur) :
      https://spuvr.github.io/maison-harman-layali/
2. Cliquez sur "Open version" sur une carte : la version s'ouvre dans un nouvel onglet.
3. Faites défiler jusqu'en bas, puis fermez l'onglet et ouvrez la suivante.

Mode clair / mode sombre : le site suit le réglage de votre téléphone.
Changez le mode de votre téléphone et rechargez la page pour voir les deux.

Avec le zip : clic droit > "Extraire tout" > dossier "Maison-Harman-Layali-5-Versions"
> double-cliquez sur "OPEN-ME.html".

À essayer : "FR | ع", les tailles 30 / 50 / 100 ml (le prix change), "Ajouter",
le trio, WhatsApp. Photos, prix et avis sont des exemples.
Dites-nous le numéro (1 à 5) de la version que vous préférez.
